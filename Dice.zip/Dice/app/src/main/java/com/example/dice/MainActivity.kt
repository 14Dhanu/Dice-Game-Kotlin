package com.example.dice

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        thr.setOnClickListener{
            var random = Random.nextInt(1,7)
            if(random == 1){
                one.text = ""
                two.text = ""
                three.text = ""
                four.text = ""
                five.text = "X"
                six.text = ""
                seven.text = ""
                eight.text = ""
                nine.text = ""
            }
            if(random == 2){
                one.text = ""
                two.text = ""
                three.text = ""
                four.text = "X"
                five.text = ""
                six.text = "X"
                seven.text = ""
                eight.text = ""
                nine.text = ""
            }
            if(random == 3){
                one.text = ""
                two.text = ""
                three.text = ""
                four.text = "X"
                five.text = "X"
                six.text = "X"
                seven.text = ""
                eight.text = ""
                nine.text = ""
            }
            if(random == 4){
                one.text = "X"
                two.text = ""
                three.text = "X"
                four.text = ""
                five.text = ""
                six.text = ""
                seven.text = "X"
                eight.text = ""
                nine.text = "X"
            }
            if(random == 5){
                one.text = "X"
                two.text = ""
                three.text = "X"
                four.text = ""
                five.text = "X"
                six.text = ""
                seven.text = "X"
                eight.text = ""
                nine.text = "X"
            }
            if(random == 6){


                one.text = "X"
                two.text = "X"
                three.text = "X"
                four.text = ""
                five.text = ""
                six.text = ""
                seven.text = "X"
                eight.text = "X"
                nine.text = "X"
            }
            Toast.makeText(this,"You Rolled "+random, Toast.LENGTH_SHORT).show()
        }
    }
}